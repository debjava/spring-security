package org.springframework.security.oauth.examples.tonr;

/**
 * @author Ryan Heaton
 */
public class SparklrException extends Exception {

  public SparklrException(String message) {
    super(message);
  }
}
